Upload the signed APK here as AKL_Electrical_Pro.apk. The website checks availability automatically.
